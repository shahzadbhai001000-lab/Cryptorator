package app.safegallery;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageManager;

/** Switches the app between its own name and icon and the name and icon of a calendar. */
final class Disguise {

	static final String NORMAL_NAME = "Cryptorator";
	static final String CALENDAR_NAME = "Calendar";
	private static final String ALIAS_NORMAL = "app.safegallery.AliasNormal";
	private static final String ALIAS_CALENDAR = "app.safegallery.AliasCalendar";

	private Disguise() {
	}

	static boolean isCalendar(Context context) {
		return context.getPackageManager().getComponentEnabledSetting(new ComponentName(context.getPackageName(), ALIAS_CALENDAR)) == PackageManager.COMPONENT_ENABLED_STATE_ENABLED;
	}

	static String name(Context context) {
		return isCalendar(context) ? CALENDAR_NAME : NORMAL_NAME;
	}

	static void set(Context context, boolean calendar) {
		PackageManager pm = context.getPackageManager();
		ComponentName normal = new ComponentName(context.getPackageName(), ALIAS_NORMAL);
		ComponentName cal = new ComponentName(context.getPackageName(), ALIAS_CALENDAR);
		// the new one is switched on first, so that the app never has no icon
		if (calendar) {
			pm.setComponentEnabledSetting(cal, PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP);
			pm.setComponentEnabledSetting(normal, PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP);
		} else {
			pm.setComponentEnabledSetting(normal, PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP);
			pm.setComponentEnabledSetting(cal, PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP);
		}
	}

	/** Shows the current name in the title bar and in the list of recent apps. */
	@SuppressWarnings("deprecation")
	static void apply(Activity activity) {
		String name = name(activity);
		activity.setTitle(name);
		activity.setTaskDescription(new ActivityManager.TaskDescription(name));
	}
}
