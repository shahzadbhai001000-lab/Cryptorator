package app.safegallery;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

/** The list of the files and folders of a vault. It is stored encrypted, so names stay hidden. */
final class Index {

	static final class Entry {
		final String id;
		String name;
		String folder;
		final String mime;
		final String file;
		final String thumb;
		final long size;
		final long added;

		Entry(String id, String name, String folder, String mime, String file, String thumb, long size, long added) {
			this.id = id;
			this.name = name;
			this.folder = folder;
			this.mime = mime;
			this.file = file;
			this.thumb = thumb;
			this.size = size;
			this.added = added;
		}
	}

	final List<Entry> entries = new ArrayList<>();
	final Set<String> folders = new TreeSet<>();

	byte[] toBytes() throws IOException {
		ByteArrayOutputStream bytes = new ByteArrayOutputStream();
		DataOutputStream out = new DataOutputStream(bytes);
		out.writeInt(1);
		out.writeInt(folders.size());
		for (String f : folders) {
			out.writeUTF(f);
		}
		out.writeInt(entries.size());
		for (Entry e : entries) {
			out.writeUTF(e.id);
			out.writeUTF(e.name);
			out.writeUTF(e.folder);
			out.writeUTF(e.mime);
			out.writeUTF(e.file);
			out.writeUTF(e.thumb);
			out.writeLong(e.size);
			out.writeLong(e.added);
		}
		out.flush();
		return bytes.toByteArray();
	}

	static Index fromBytes(byte[] data) throws IOException {
		DataInputStream in = new DataInputStream(new ByteArrayInputStream(data));
		if (in.readInt() != 1) {
			throw new IOException("Unknown index version");
		}
		Index index = new Index();
		int folders = in.readInt();
		for (int i = 0; i < folders; i++) {
			index.folders.add(in.readUTF());
		}
		int entries = in.readInt();
		for (int i = 0; i < entries; i++) {
			index.entries.add(new Entry(in.readUTF(), in.readUTF(), in.readUTF(), in.readUTF(), in.readUTF(), in.readUTF(), in.readLong(), in.readLong()));
		}
		return index;
	}

	static String parentOf(String folder) {
		int slash = folder.lastIndexOf('/');
		return slash < 0 ? "" : folder.substring(0, slash);
	}

	static String nameOf(String folder) {
		int slash = folder.lastIndexOf('/');
		return slash < 0 ? folder : folder.substring(slash + 1);
	}
}
