package app.safegallery;

import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.security.GeneralSecurityException;
import java.security.SecureRandom;
import java.util.Arrays;

import javax.crypto.Cipher;
import javax.crypto.Mac;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * File format ("SGF1"): 4 bytes magic, 16 bytes random file salt, then chunks of up to 64 KiB of plaintext, each
 * sealed with AES-256-GCM (16 byte tag). The key of a file is HMAC-SHA256(masterKey, fileSalt). The nonce of a chunk is
 * its index, and the last chunk is marked in the authenticated data, so chunks can't be reordered or cut off. The size
 * of the plaintext follows from the size of the file, and any position can be read without reading what comes before.
 */
final class Crypto {

	static final int CHUNK = 65536;
	static final int TAG = 16;
	static final int HEADER = 20;

	private static final byte[] MAGIC = {'S', 'G', 'F', '1'};
	private static final SecureRandom RNG = new SecureRandom();

	private Crypto() {
	}

	static byte[] random(int n) {
		byte[] b = new byte[n];
		RNG.nextBytes(b);
		return b;
	}

	static byte[] deriveKey(char[] password, byte[] salt, int iterations) throws IOException {
		PBEKeySpec spec = new PBEKeySpec(password, salt, iterations, 256);
		try {
			return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
		} catch (GeneralSecurityException e) {
			throw new IOException(e);
		} finally {
			spec.clearPassword();
		}
	}

	private static byte[] fileKey(byte[] master, byte[] fileSalt) throws IOException {
		try {
			Mac mac = Mac.getInstance("HmacSHA256");
			mac.init(new SecretKeySpec(master, "HmacSHA256"));
			return mac.doFinal(fileSalt);
		} catch (GeneralSecurityException e) {
			throw new IOException(e);
		}
	}

	private static byte[] crypt(int mode, SecretKeySpec key, long index, boolean last, byte[] in, int off, int len) throws GeneralSecurityException {
		Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
		byte[] nonce = new byte[12];
		ByteBuffer.wrap(nonce).putLong(4, index);
		cipher.init(mode, key, new GCMParameterSpec(128, nonce));
		cipher.updateAAD(new byte[]{(byte) (last ? 1 : 0)});
		return cipher.doFinal(in, off, len);
	}

	private static int readFully(InputStream in, byte[] b) throws IOException {
		int total = 0;
		while (total < b.length) {
			int n = in.read(b, total, b.length - total);
			if (n < 0) {
				break;
			}
			total += n;
		}
		return total;
	}

	static void encrypt(byte[] master, InputStream in, OutputStream out) throws IOException {
		byte[] salt = random(16);
		out.write(MAGIC);
		out.write(salt);
		SecretKeySpec key = new SecretKeySpec(fileKey(master, salt), "AES");
		byte[] cur = new byte[CHUNK];
		byte[] next = new byte[CHUNK];
		int curLen = readFully(in, cur);
		long index = 0;
		try {
			while (true) {
				int nextLen = curLen == CHUNK ? readFully(in, next) : 0;
				boolean last = nextLen == 0;
				out.write(crypt(Cipher.ENCRYPT_MODE, key, index, last, cur, 0, curLen));
				if (last) {
					break;
				}
				byte[] swap = cur;
				cur = next;
				next = swap;
				curLen = nextLen;
				index++;
			}
		} catch (GeneralSecurityException e) {
			throw new IOException(e);
		}
	}

	static byte[] encryptBytes(byte[] master, byte[] plain) throws IOException {
		ByteArrayOutputStream out = new ByteArrayOutputStream(plain.length + 64);
		encrypt(master, new java.io.ByteArrayInputStream(plain), out);
		return out.toByteArray();
	}

	static byte[] decryptBytes(byte[] master, byte[] enc) throws IOException {
		try (Reader reader = new Reader(master, new ArraySource(enc), enc.length)) {
			byte[] out = new byte[(int) reader.size()];
			int done = 0;
			while (done < out.length) {
				int n = reader.read(done, out, done, out.length - done);
				if (n <= 0) {
					throw new IOException("Unexpected end of data");
				}
				done += n;
			}
			return out;
		}
	}

	static long plainSize(long encLen) throws IOException {
		long body = encLen - HEADER;
		long full = CHUNK + TAG;
		if (body < TAG) {
			throw new IOException("File too short");
		}
		long chunks = (body + full - 1) / full;
		long lastPlain = body - (chunks - 1) * full - TAG;
		if (lastPlain < 0 || lastPlain > CHUNK) {
			throw new IOException("File has a wrong size");
		}
		return (chunks - 1) * CHUNK + lastPlain;
	}

	interface RandomSource extends Closeable {
		int readAt(long position, byte[] dst, int off, int len) throws IOException;
	}

	static final class ArraySource implements RandomSource {
		private final byte[] data;

		ArraySource(byte[] data) {
			this.data = data;
		}

		@Override
		public int readAt(long position, byte[] dst, int off, int len) {
			if (position >= data.length) {
				return -1;
			}
			int n = (int) Math.min(len, data.length - position);
			System.arraycopy(data, (int) position, dst, off, n);
			return n;
		}

		@Override
		public void close() {
		}
	}

	/** Reads any part of an encrypted file. */
	static final class Reader implements Closeable {

		private final RandomSource source;
		private final SecretKeySpec key;
		private final long encLen;
		private final long size;
		private final long chunks;
		private final byte[] encBuf = new byte[CHUNK + TAG];
		private final byte[] cache = new byte[CHUNK];
		private long cachedIndex = -1;
		private int cacheLen;

		Reader(byte[] master, RandomSource source, long encLen) throws IOException {
			this.source = source;
			this.encLen = encLen;
			this.size = plainSize(encLen);
			this.chunks = (encLen - HEADER + (CHUNK + TAG) - 1) / (CHUNK + TAG);
			byte[] header = new byte[HEADER];
			readExactly(0, header, HEADER);
			if (!Arrays.equals(Arrays.copyOf(header, 4), MAGIC)) {
				throw new IOException("Not an encrypted file of this app");
			}
			this.key = new SecretKeySpec(fileKey(master, Arrays.copyOfRange(header, 4, HEADER)), "AES");
		}

		long size() {
			return size;
		}

		/** @return the number of bytes read, or -1 at the end */
		synchronized int read(long position, byte[] dst, int off, int len) throws IOException {
			if (position >= size) {
				return -1;
			}
			int total = 0;
			while (total < len && position < size) {
				long index = position / CHUNK;
				load(index);
				int inChunk = (int) (position - index * CHUNK);
				int n = Math.min(len - total, cacheLen - inChunk);
				System.arraycopy(cache, inChunk, dst, off + total, n);
				total += n;
				position += n;
			}
			return total;
		}

		private void load(long index) throws IOException {
			if (index == cachedIndex) {
				return;
			}
			long start = HEADER + index * (CHUNK + TAG);
			boolean last = index == chunks - 1;
			int length = (int) (last ? encLen - start : CHUNK + TAG);
			readExactly(start, encBuf, length);
			try {
				byte[] plain = crypt(Cipher.DECRYPT_MODE, key, index, last, encBuf, 0, length);
				System.arraycopy(plain, 0, cache, 0, plain.length);
				cacheLen = plain.length;
				cachedIndex = index;
			} catch (GeneralSecurityException e) {
				cachedIndex = -1;
				throw new IOException("File is damaged or was changed", e);
			}
		}

		private void readExactly(long position, byte[] dst, int len) throws IOException {
			int done = 0;
			while (done < len) {
				int n = source.readAt(position + done, dst, done, len - done);
				if (n <= 0) {
					throw new IOException("Unexpected end of file");
				}
				done += n;
			}
		}

		@Override
		public void close() throws IOException {
			source.close();
		}
	}
}
