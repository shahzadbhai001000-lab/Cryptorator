package app.safegallery;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.hardware.biometrics.BiometricPrompt;
import android.os.CancellationSignal;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyPermanentlyInvalidatedException;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import java.security.KeyStore;
import java.security.MessageDigest;
import java.util.concurrent.atomic.AtomicBoolean;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/**
 * Fingerprint unlock. The password of a vault is encrypted with a key that never leaves the phone's secure hardware
 * and that can only be used right after a fingerprint was accepted. The key stops working if a fingerprint is added
 * to the phone, and then the password is asked for again.
 */
final class Biometrics {

	interface Result {
		/** @param secret the password bytes (when unlocking) or null (when enabling) */
		void ok(byte[] secret);

		/** @param message null if the person cancelled or chose to use the password */
		void fail(String message);
	}

	private interface CipherTask {
		byte[] run(Cipher cipher) throws Exception;
	}

	private static final String PREFS = "fingerprint";
	private static final String KEYSTORE = "AndroidKeyStore";

	private Biometrics() {
	}

	static boolean available(Context context) {
		return context.getPackageManager().hasSystemFeature(PackageManager.FEATURE_FINGERPRINT);
	}

	private static String id(String tree) {
		try {
			byte[] hash = MessageDigest.getInstance("SHA-256").digest(tree.getBytes("UTF-8"));
			StringBuilder s = new StringBuilder("pv_");
			for (int i = 0; i < 8; i++) {
				s.append(String.format("%02x", hash[i]));
			}
			return s.toString();
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

	private static SharedPreferences prefs(Context context) {
		return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
	}

	static boolean enabled(Context context, String tree) {
		return prefs(context).contains(id(tree) + ".ct");
	}

	static void disable(Context context, String tree) {
		String id = id(tree);
		prefs(context).edit().remove(id + ".iv").remove(id + ".ct").apply();
		try {
			KeyStore ks = KeyStore.getInstance(KEYSTORE);
			ks.load(null);
			ks.deleteEntry(id);
		} catch (Exception ignored) {
			// no key left to delete
		}
	}

	/** Asks for a fingerprint and then stores [secret] so that a fingerprint can unlock the vault. */
	static void enable(final Activity activity, final String tree, final byte[] secret, Result result) {
		final String id = id(tree);
		try {
			KeyStore ks = KeyStore.getInstance(KEYSTORE);
			ks.load(null);
			if (ks.containsAlias(id)) {
				ks.deleteEntry(id);
			}
			KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, KEYSTORE);
			generator.init(new KeyGenParameterSpec.Builder(id, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
					.setBlockModes(KeyProperties.BLOCK_MODE_GCM)
					.setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
					.setKeySize(256)
					.setUserAuthenticationRequired(true)
					.setInvalidatedByBiometricEnrollment(true)
					.build());
			SecretKey key = generator.generateKey();
			Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
			cipher.init(Cipher.ENCRYPT_MODE, key);
			prompt(activity, cipher, "Enable fingerprint unlock", c -> {
				byte[] encrypted = c.doFinal(secret);
				prefs(activity).edit()
						.putString(id + ".iv", Base64.encodeToString(c.getIV(), Base64.NO_WRAP))
						.putString(id + ".ct", Base64.encodeToString(encrypted, Base64.NO_WRAP))
						.apply();
				return null;
			}, result);
		} catch (Exception e) {
			disable(activity, tree);
			result.fail(e.getMessage() != null ? e.getMessage() : e.toString());
		}
	}

	/** Asks for a fingerprint and returns the stored password bytes. */
	static void unlock(final Activity activity, final String tree, Result result) {
		final String id = id(tree);
		try {
			byte[] iv = Base64.decode(prefs(activity).getString(id + ".iv", ""), Base64.NO_WRAP);
			final byte[] encrypted = Base64.decode(prefs(activity).getString(id + ".ct", ""), Base64.NO_WRAP);
			KeyStore ks = KeyStore.getInstance(KEYSTORE);
			ks.load(null);
			SecretKey key = (SecretKey) ks.getKey(id, null);
			if (key == null) {
				disable(activity, tree);
				result.fail("Fingerprint unlock is not set up any more. Use your password.");
				return;
			}
			Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
			cipher.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(128, iv));
			prompt(activity, cipher, "Unlock vault", c -> c.doFinal(encrypted), result);
		} catch (KeyPermanentlyInvalidatedException e) {
			disable(activity, tree);
			result.fail("Your fingerprints changed. Use your password.");
		} catch (Exception e) {
			result.fail(e.getMessage() != null ? e.getMessage() : e.toString());
		}
	}

	private static void prompt(Activity activity, Cipher cipher, String title, final CipherTask task, final Result result) {
		final AtomicBoolean finished = new AtomicBoolean(false);
		BiometricPrompt prompt = new BiometricPrompt.Builder(activity)
				.setTitle(title)
				.setNegativeButton("Use password", activity.getMainExecutor(), (dialog, which) -> {
					if (finished.compareAndSet(false, true)) {
						result.fail(null);
					}
				})
				.build();
		prompt.authenticate(new BiometricPrompt.CryptoObject(cipher), new CancellationSignal(), activity.getMainExecutor(), new BiometricPrompt.AuthenticationCallback() {
			@Override
			public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult authentication) {
				if (!finished.compareAndSet(false, true)) {
					return;
				}
				try {
					result.ok(task.run(authentication.getCryptoObject().getCipher()));
				} catch (Exception e) {
					result.fail(e.getMessage() != null ? e.getMessage() : e.toString());
				}
			}

			@Override
			public void onAuthenticationError(int errorCode, CharSequence errString) {
				if (!finished.compareAndSet(false, true)) {
					return;
				}
				boolean cancelled = errorCode == BiometricPrompt.BIOMETRIC_ERROR_USER_CANCELED || errorCode == BiometricPrompt.BIOMETRIC_ERROR_CANCELED;
				result.fail(cancelled ? null : String.valueOf(errString));
			}
		});
	}
}
