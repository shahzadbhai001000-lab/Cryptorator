package app.safegallery;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

/** One square cell of the grid: a thumbnail, or an icon with the name, with a play badge on videos. */
final class Tile extends FrameLayout {

	private final ImageView image;
	private final TextView icon;
	private final TextView label;
	private final View badge;
	private final View selection;

	Tile(Context context) {
		super(context);
		setBackgroundColor(0xFF0F0F0F);

		image = new ImageView(context);
		image.setScaleType(ImageView.ScaleType.CENTER_CROP);
		addView(image, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));

		icon = new TextView(context);
		icon.setGravity(Gravity.CENTER);
		icon.setTextSize(TypedValue.COMPLEX_UNIT_SP, 34);
		addView(icon, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));

		label = new TextView(context);
		label.setTextColor(Color.WHITE);
		label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
		label.setSingleLine(true);
		label.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
		label.setGravity(Gravity.CENTER);
		label.setBackgroundColor(0x99000000);
		int pad = dp(3);
		label.setPadding(pad, pad, pad, pad);
		addView(label, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT, Gravity.BOTTOM));

		badge = new View(context) {
			private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
			private final Path triangle = new Path();

			@Override
			protected void onDraw(Canvas canvas) {
				float w = getWidth();
				float h = getHeight();
				paint.setColor(0x99000000);
				canvas.drawCircle(w / 2, h / 2, w / 2, paint);
				paint.setColor(Color.WHITE);
				triangle.reset();
				triangle.moveTo(w * 0.39f, h * 0.29f);
				triangle.lineTo(w * 0.39f, h * 0.71f);
				triangle.lineTo(w * 0.74f, h * 0.5f);
				triangle.close();
				canvas.drawPath(triangle, paint);
			}
		};
		addView(badge, new LayoutParams(dp(32), dp(32), Gravity.CENTER));

		selection = new TextView(context);
		selection.setBackgroundColor(0x884CAF50);
		((TextView) selection).setText("✓");
		((TextView) selection).setTextColor(Color.WHITE);
		((TextView) selection).setTextSize(TypedValue.COMPLEX_UNIT_SP, 28);
		((TextView) selection).setGravity(Gravity.CENTER);
		addView(selection, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
	}

	private int dp(int v) {
		return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
	}

	@Override
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		super.onMeasure(widthMeasureSpec, widthMeasureSpec);
	}

	ImageView imageView() {
		return image;
	}

	void bind(String name, boolean folder, String mime, boolean hasThumbnail, boolean selected) {
		boolean video = mime.startsWith("video/");
		icon.setVisibility(hasThumbnail ? GONE : VISIBLE);
		label.setVisibility(hasThumbnail ? GONE : VISIBLE);
		label.setText(name);
		if (!hasThumbnail) {
			image.setImageDrawable(null);
			icon.setText(folder ? "📁" : video ? "🎬" : mime.startsWith("image/") ? "🖼" : mime.startsWith("audio/") ? "🎵" : "📄");
		}
		badge.setVisibility(video ? VISIBLE : GONE);
		selection.setVisibility(selected ? VISIBLE : GONE);
	}

	void showThumbnail(Bitmap bitmap) {
		image.setImageBitmap(bitmap);
	}
}
