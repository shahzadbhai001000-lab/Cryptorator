package app.safegallery;

/** The vault that is unlocked right now. It only lives in memory. */
final class Session {

	static volatile Vault vault;

	private Session() {
	}

	static void lock() {
		vault = null;
	}
}
