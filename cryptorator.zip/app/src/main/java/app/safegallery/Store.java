package app.safegallery;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/** Where the files of a vault are kept: one flat folder. */
interface Store {

	boolean exists(String name) throws IOException;

	/** Creates the file, or replaces it if it exists. */
	OutputStream create(String name) throws IOException;

	InputStream open(String name) throws IOException;

	long length(String name) throws IOException;

	Crypto.RandomSource randomAccess(String name) throws IOException;

	void delete(String name) throws IOException;
}
