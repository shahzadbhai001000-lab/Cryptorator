package app.safegallery;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.media.MediaMetadataRetriever;
import android.net.Uri;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

/** Makes the small preview picture of an image, GIF or video before it is encrypted. */
final class Thumbs {

	private static final int SIZE = 320;

	private Thumbs() {
	}

	/** @return a JPEG, or null if no picture can be made of the file */
	static byte[] make(Context context, Uri uri, String mime) {
		try {
			Bitmap bitmap = mime.startsWith("video/") ? videoFrame(context, uri) : image(context, uri);
			if (bitmap == null) {
				return null;
			}
			bitmap = scaled(bitmap);
			Bitmap opaque = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), Bitmap.Config.ARGB_8888);
			Canvas canvas = new Canvas(opaque);
			canvas.drawColor(Color.BLACK);
			canvas.drawBitmap(bitmap, 0, 0, null);
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			return opaque.compress(Bitmap.CompressFormat.JPEG, 80, out) ? out.toByteArray() : null;
		} catch (Exception | OutOfMemoryError e) {
			return null;
		}
	}

	private static Bitmap image(Context context, Uri uri) throws Exception {
		BitmapFactory.Options bounds = new BitmapFactory.Options();
		bounds.inJustDecodeBounds = true;
		try (InputStream in = context.getContentResolver().openInputStream(uri)) {
			BitmapFactory.decodeStream(in, null, bounds);
		}
		if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
			return null;
		}
		int sample = 1;
		while (Math.min(bounds.outWidth, bounds.outHeight) / (sample * 2) >= SIZE) {
			sample *= 2;
		}
		BitmapFactory.Options options = new BitmapFactory.Options();
		options.inSampleSize = sample;
		Bitmap bitmap;
		try (InputStream in = context.getContentResolver().openInputStream(uri)) {
			bitmap = BitmapFactory.decodeStream(in, null, options);
		}
		if (bitmap == null) {
			return null;
		}
		int degrees = 0;
		try (InputStream in = context.getContentResolver().openInputStream(uri)) {
			int orientation = new ExifInterface(in).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
			if (orientation == ExifInterface.ORIENTATION_ROTATE_90) {
				degrees = 90;
			} else if (orientation == ExifInterface.ORIENTATION_ROTATE_180) {
				degrees = 180;
			} else if (orientation == ExifInterface.ORIENTATION_ROTATE_270) {
				degrees = 270;
			}
		} catch (Exception ignored) {
			// no orientation known
		}
		if (degrees != 0) {
			Matrix matrix = new Matrix();
			matrix.postRotate(degrees);
			bitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
		}
		return bitmap;
	}

	private static Bitmap videoFrame(Context context, Uri uri) {
		MediaMetadataRetriever retriever = new MediaMetadataRetriever();
		try {
			retriever.setDataSource(context, uri);
			Bitmap frame = retriever.getFrameAtTime(1_000_000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
			return frame != null ? frame : retriever.getFrameAtTime(-1L);
		} catch (Exception e) {
			return null;
		} finally {
			try {
				retriever.release();
			} catch (Exception ignored) {
				// nothing to release
			}
		}
	}

	private static Bitmap scaled(Bitmap bitmap) {
		float scale = (float) SIZE / Math.min(bitmap.getWidth(), bitmap.getHeight());
		if (scale >= 1f) {
			return bitmap;
		}
		return Bitmap.createScaledBitmap(bitmap, Math.max(1, (int) (bitmap.getWidth() * scale)), Math.max(1, (int) (bitmap.getHeight() * scale)), true);
	}
}
