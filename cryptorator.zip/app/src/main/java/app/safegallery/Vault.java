package app.safegallery;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Properties;

/** An unlocked vault: the master key, the index and the store. All changes go through here. */
final class Vault {

	static final class WrongPasswordException extends IOException {
		WrongPasswordException() {
			super("Wrong password");
		}
	}

	static final String CFG = "vault.cfg";
	static final String INDEX = "index.sgv";
	static final String INDEX_BAK = "index.bak";
	private static final int ITERATIONS = 400000;
	private static final byte[] CHECK = "SAFE-GALLERY-VAULT-1".getBytes(StandardCharsets.UTF_8);

	private final Store store;
	private final byte[] master;
	private final Index index;

	private Vault(Store store, byte[] master, Index index) {
		this.store = store;
		this.master = master;
		this.index = index;
	}

	static Vault create(Store store, char[] password) throws IOException {
		if (store.exists(CFG)) {
			throw new IOException("This folder already contains a vault");
		}
		byte[] salt = Crypto.random(16);
		byte[] key = Crypto.deriveKey(password, salt, ITERATIONS);
		Properties p = new Properties();
		p.setProperty("version", "1");
		p.setProperty("salt", Base64.getEncoder().encodeToString(salt));
		p.setProperty("iterations", String.valueOf(ITERATIONS));
		p.setProperty("check", Base64.getEncoder().encodeToString(Crypto.encryptBytes(key, CHECK)));
		try (OutputStream out = store.create(CFG)) {
			p.store(out, null);
		}
		Vault vault = new Vault(store, key, new Index());
		vault.saveIndex();
		return vault;
	}

	static Vault open(Store store, char[] password) throws IOException {
		if (!store.exists(CFG)) {
			throw new FileNotFoundException("There is no vault in this folder");
		}
		Properties p = new Properties();
		try (InputStream in = store.open(CFG)) {
			p.load(in);
		}
		byte[] salt = Base64.getDecoder().decode(p.getProperty("salt", ""));
		int iterations = Integer.parseInt(p.getProperty("iterations", String.valueOf(ITERATIONS)));
		byte[] key = Crypto.deriveKey(password, salt, iterations);
		try {
			byte[] check = Crypto.decryptBytes(key, Base64.getDecoder().decode(p.getProperty("check", "")));
			if (!java.util.Arrays.equals(check, CHECK)) {
				throw new WrongPasswordException();
			}
		} catch (IOException e) {
			throw new WrongPasswordException();
		}
		return new Vault(store, key, loadIndex(store, key));
	}

	private static Index loadIndex(Store store, byte[] key) throws IOException {
		IOException first = null;
		for (String name : new String[]{INDEX, INDEX_BAK}) {
			try {
				if (store.exists(name)) {
					return Index.fromBytes(Crypto.decryptBytes(key, readAll(store.open(name))));
				}
			} catch (IOException e) {
				if (first == null) {
					first = e;
				}
			}
		}
		throw first != null ? first : new FileNotFoundException("The vault's index is missing");
	}

	private static byte[] readAll(InputStream in) throws IOException {
		try (InputStream input = in) {
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			byte[] buf = new byte[65536];
			int n;
			while ((n = input.read(buf)) >= 0) {
				out.write(buf, 0, n);
			}
			return out.toByteArray();
		}
	}

	private void saveIndex() throws IOException {
		byte[] enc = Crypto.encryptBytes(master, index.toBytes());
		try (OutputStream out = store.create(INDEX)) {
			out.write(enc);
		}
		try (OutputStream out = store.create(INDEX_BAK)) {
			out.write(enc);
		}
	}

	synchronized List<Index.Entry> entriesIn(String folder) {
		List<Index.Entry> result = new ArrayList<>();
		for (Index.Entry e : index.entries) {
			if (e.folder.equals(folder)) {
				result.add(e);
			}
		}
		return result;
	}

	synchronized List<String> foldersIn(String parent) {
		List<String> result = new ArrayList<>();
		for (String f : index.folders) {
			if (Index.parentOf(f).equals(parent)) {
				result.add(f);
			}
		}
		return result;
	}

	synchronized List<String> allFolders() {
		return new ArrayList<>(index.folders);
	}

	synchronized Index.Entry find(String id) {
		for (Index.Entry e : index.entries) {
			if (e.id.equals(id)) {
				return e;
			}
		}
		return null;
	}

	synchronized Index.Entry addFile(InputStream in, String name, String mime, String folder, byte[] thumbnail) throws IOException {
		String id = hex(Crypto.random(12));
		String file = id + ".sg";
		String thumbFile = "";
		try {
			try (OutputStream out = store.create(file)) {
				Crypto.encrypt(master, in, out);
			}
			if (thumbnail != null) {
				thumbFile = id + ".t";
				try (OutputStream out = store.create(thumbFile)) {
					out.write(Crypto.encryptBytes(master, thumbnail));
				}
			}
			Index.Entry entry = new Index.Entry(id, name, folder, mime, file, thumbFile, Crypto.plainSize(store.length(file)), System.currentTimeMillis());
			index.entries.add(entry);
			saveIndex();
			return entry;
		} catch (IOException | RuntimeException e) {
			quietDelete(file);
			quietDelete(thumbFile);
			index.entries.removeIf(x -> x.id.equals(id));
			throw e;
		}
	}

	synchronized byte[] readThumbnail(Index.Entry entry) throws IOException {
		if (entry.thumb.isEmpty()) {
			return null;
		}
		return Crypto.decryptBytes(master, readAll(store.open(entry.thumb)));
	}

	Crypto.Reader openReader(Index.Entry entry) throws IOException {
		Crypto.RandomSource source = store.randomAccess(entry.file);
		try {
			return new Crypto.Reader(master, source, store.length(entry.file));
		} catch (IOException | RuntimeException e) {
			source.close();
			throw e;
		}
	}

	void export(Index.Entry entry, OutputStream out) throws IOException {
		try (Crypto.Reader reader = openReader(entry)) {
			byte[] buf = new byte[Crypto.CHUNK];
			long position = 0;
			int n;
			while ((n = reader.read(position, buf, 0, buf.length)) > 0) {
				out.write(buf, 0, n);
				position += n;
			}
		}
	}

	synchronized void createFolder(String path) throws IOException {
		index.folders.add(path);
		saveIndex();
	}

	synchronized void delete(Collection<Index.Entry> entries) throws IOException {
		for (Index.Entry e : entries) {
			quietDelete(e.file);
			quietDelete(e.thumb);
			index.entries.remove(e);
		}
		saveIndex();
	}

	/** Deletes the folder with everything in it. */
	synchronized void deleteFolder(String path) throws IOException {
		List<Index.Entry> inside = new ArrayList<>();
		for (Index.Entry e : index.entries) {
			if (e.folder.equals(path) || e.folder.startsWith(path + "/")) {
				inside.add(e);
			}
		}
		for (Index.Entry e : inside) {
			quietDelete(e.file);
			quietDelete(e.thumb);
		}
		index.entries.removeAll(inside);
		index.folders.removeIf(f -> f.equals(path) || f.startsWith(path + "/"));
		saveIndex();
	}

	synchronized void move(Collection<Index.Entry> entries, String folder) throws IOException {
		for (Index.Entry e : entries) {
			e.folder = folder;
		}
		saveIndex();
	}

	synchronized void rename(Index.Entry entry, String name) throws IOException {
		entry.name = name;
		saveIndex();
	}

	private void quietDelete(String name) {
		try {
			if (name != null && !name.isEmpty() && store.exists(name)) {
				store.delete(name);
			}
		} catch (IOException ignored) {
			// leaves a file nobody refers to
		}
	}

	private static String hex(byte[] b) {
		StringBuilder s = new StringBuilder();
		for (byte x : b) {
			s.append(String.format("%02x", x));
		}
		return s.toString();
	}

	static List<Index.Entry> sortedNewestFirst(List<Index.Entry> entries) {
		List<Index.Entry> copy = new ArrayList<>(entries);
		Collections.sort(copy, (a, b) -> Long.compare(b.added, a.added));
		return copy;
	}
}
